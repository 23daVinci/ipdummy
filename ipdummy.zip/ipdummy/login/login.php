<?php include "includes/alogin_fun.php"; ?>
<html>

<head>
    <title>QBank</title>
    <link rel="stylesheet" href="css/login.css">
    <?php include "includes/link.php"; ?>
    <link rel="icon" href="../favicon.png" type="image/x-icon">
</head>

<body>


    <div class="body"></div>

    <div class="grad"></div>
    <div class="row" style="position: relative; top: 200px;">
        <div class="col-sm-3">
            <p> </p>
        </div>
        <div class="row">
            <div class="col-sm-3 jumbotron" style="background-color: rgba(0, 0, 0, 0.53)">
                <h1 style="text-align: center; color:white"><span style="color: blue">QBank</span> Login</h1><br>
                <br>
                <br>
                <br>
                <br>
            </div>
            <div class="col-sm-3 jumbotron" style="background-color: rgba(0, 0, 0, 0.53)">
                <br>
                <form action="" method="post" style="position: relative; top: 5px;">
                    <input type="text" class="form-control" name="username" placeholder="username">
                    <br>
                    <input type="text" class="form-control" name="password" placeholder="password">
                    <br>
                    <input type="submit" class="btn btn-warning" name="login" value="Login"><br>

                    <br>
                </form>
            </div>
        </div>
        <div class="col-sm-3">
            <p> </p>
        </div>
    </div>
</body>

</html>
